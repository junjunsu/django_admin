CREATE TRIGGER tri_after_insert_tb1
AFTER INSERT ON student
FOR EACH ROW
  BEGIN
   update class set caption = '三' where cid = 4;
END;
