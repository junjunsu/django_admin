CREATE TRIGGER tri_before_insert_tb1
BEFORE INSERT ON student
FOR EACH ROW
  BEGIN
   update class set caption = '二' where cid = 4;
END;
