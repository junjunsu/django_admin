CREATE PROCEDURE p2(IN i1 INT, IN i2 INT, OUT i3 INT, INOUT i4 INT)
  BEGIN
DECLARE tmp1 int;
DECLARE tmp2 int default 0;
set tmp1 = 1;
set i3 = i3+100;
set i4 = tmp1 + 100+i1+i2;
select * from student;
end;
