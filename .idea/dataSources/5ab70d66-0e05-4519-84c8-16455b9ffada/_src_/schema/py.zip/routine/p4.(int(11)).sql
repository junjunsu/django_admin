CREATE PROCEDURE p4(IN nid INT)
  BEGIN
SET @id = nid;
PREPARE prod FROM 'select * from student where sid > ?';
EXECUTE prod USING @id;
DEALLOCATE prepare prod; 
END;
