CREATE PROCEDURE p3()
  begin
    declare ssid int; -- 自定义变量1
    declare ssname varchar(50); -- 自定义变量2
    DECLARE done INT DEFAULT FALSE;


    DECLARE my_cursor CURSOR FOR select sid,sname from student;  -- 声明游标
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;  -- 异常处理 出现异常 done改为true

    open my_cursor; -- 打开游标
        xxoo: LOOP
        -- 逐个取出当前记录的字段的值，需要判断是否在
            fetch my_cursor into ssid,ssname;
            if done then  
                leave xxoo;  -- done 是 true的话跳过
            END IF;
            insert into teacher(tname) values(ssname); -- 否则插入一条数据
        end loop xxoo;
    close my_cursor;  -- 关闭游标
end;
