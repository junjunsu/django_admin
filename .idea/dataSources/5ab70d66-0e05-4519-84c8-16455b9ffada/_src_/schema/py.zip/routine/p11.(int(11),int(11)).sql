CREATE PROCEDURE p11(IN n1 INT, INOUT n3 INT, OUT n2 INT, OUT n4 INT)
  begin
declare temp1 int ;
declare temp2 int default 0;
set n4 = 20;
select * from student;
set n2 = n1 + 100;
set n3 = n3 + n1 + 100 +n4;
end;
