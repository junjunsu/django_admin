CREATE PROCEDURE p1(OUT p_return_code TINYINT)
  BEGIN
  DECLARE exit handler for sqlexception  -- 捕获错误异常
  BEGIN
    -- ERROR
    set p_return_code = 1;
    rollback;
  END;

  DECLARE exit handler for sqlwarning
  BEGIN
    -- WARNING
    set p_return_code = 2;
    rollback;
  END;

  START TRANSACTION;
    DELETE from tb1;
    insert into tb2(name)values('seven');
  COMMIT;

  -- SUCCESS
  set p_return_code = 0;

  END;
