CREATE TRIGGER tg4
AFTER UPDATE ON tb_orders
FOR EACH ROW
  begin

update tb_goods set num = num+old.much-new.much where id = old.good_id/new.good_id;

end;
