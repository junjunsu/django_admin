CREATE TRIGGER tg2
AFTER INSERT ON tb_orders
FOR EACH ROW
  BEGIN
update tb_goods set num = num - new.much where id = new.good_id;
end;
