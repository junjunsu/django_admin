CREATE TRIGGER tg1
AFTER INSERT ON tb_orders
FOR EACH ROW
  begin
update tb_goods  set num=num-3 where id=1;
end;
