CREATE TRIGGER tg3
AFTER DELETE ON tb_orders
FOR EACH ROW
  begin

update tb_goods set num = num + old.much where id = old.good_id;

end;
